import java.util.Scanner;

public class dersNotu {
    public static void main(String[] args) {

        int mat, turkce, fizik, kimya, tarih;

        Scanner inp = new Scanner(System.in);

        System.out.println("matematik notunu giriniz:");
        mat = inp.nextInt();
        if (mat > 100 || mat < 0) {
            System.out.println("lütfen 0-100 arasında bir sayı Giriniz:");
            return;
        }

        System.out.println("turkçe notunu giriniz:");
        turkce = inp.nextInt();
        if (turkce > 100 || turkce < 0) {
            System.out.println("lütfen 0-100 arasında bir sayı Giriniz:");
        }

        System.out.println("fizik notunu giriniz:");
        fizik = inp.nextInt();
        if (fizik > 100 || fizik < 0) {
            System.out.println("lütfen 0-100 arasında bir sayı Giriniz:");
        }

        System.out.println("kimya notunu giriniz:");
        kimya = inp.nextInt();
        if (kimya > 100 || kimya < 0) {
            System.out.println("lütfen 0-100 arasında bir sayı Giriniz:");
        }

        System.out.println("tarih notunu giriniz:");
        tarih = inp.nextInt();
        if (tarih > 100 || tarih < 0) {
            System.out.println("lütfen 0-100 arasında bir sayı Giriniz:");
        }



        double average = (mat + turkce + fizik + kimya + tarih) / 5;


        if (average <= 55) {

            System.out.println("sınıfta kaldınız, seneye görüşmek üzere!");
        } else {

            System.out.println("TEBRİKLER! Sınıfı Geçtiniz");

        }


        System.out.println("ortalamız:" + average);

    }
}






